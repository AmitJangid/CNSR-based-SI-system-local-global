#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
from numba import jit # type: ignore
import pickle
from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
from operator import itemgetter
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import matplotlib as mpl # type: ignore
import seaborn as sns # type: ignore
from matplotlib.ticker import FormatStrFormatter # type: ignore
import matplotlib.colors as mcolors  # type: ignore
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

energy_interaction = np.array([[-1,0,0,0],[0,-0.75,-0.25,-0.25],[0,-0.25,1,-1.25],[0,-0.25,-1.25,1]])
#@jit(nopython=True)
def energyOfIntPair(RNAse, FBoxg):  return sum([energy_interaction[int(x),int(y)] for x, y in zip(RNAse, FBoxg)])
def HammingDistance(inputX, inputY):
    hDistance = 0
    for x, y in zip(inputX, inputY):
        if x != y: hDistance += 1
    return hDistance

color1, color2, color3 = mcolors.TABLEAU_COLORS['tab:red'], mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:green']
Color = [color1, color2, color3]

weight = [0.5, 0.265, 0.113, 0.122]
def plot_unique_Gene_Paper(input_Var):


    plt.figure(figsize=(4.25,7.25))
    #plt.subplots_adjust(top=0.946, bottom=0.114, left=0.052, right=0.986, hspace=0.414, wspace=0.30)
    plt.subplots_adjust(top=0.970, bottom=0.047, left=0.093, right=0.993, hspace=0.620, wspace=0.425)
    plt.subplots_adjust(top=0.9745, bottom=0.047, left=0.093, right=0.995, hspace=0.620, wspace=0.425)
    #plt.figure(figsize=(4.25,6.15))
    #plt.subplots_adjust(top=0.965, bottom=0.114, left=0.0933, right=0.979, hspace=0.457, wspace=0.30)
    fontsizeX, fontsizeY, fonttitle, fontticks = 8, 8, 8, 6
    AminoAcid = ['H', 'P', '+', '-']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m'];
    EnergyValue = [-7, -3]
    alpha = 0.10



    Samples = 25

    def bin_Control(input_Var_1, input_Var_2, binSize):
        data_X, data_Y = input_Var_1, input_Var_2

        Check_Bin = [0]  # corresponds to first bin [0 - firstBinEnd)
        for i in range(int(np.max(data_X)/(2*binSize)) + 2):
            if i == 0:
                Check_Bin.append(Check_Bin[-1]+binSize)
            else:
                Check_Bin.append(Check_Bin[-1]+2*binSize)

        output_Bin_Data = []; center_Bin = []; bib_Interval = binSize

        for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
            current_Bin_Data = []
            for Key, Value in zip(data_X, data_Y):
                if Key >= bin1 and Key < bin2:
                    current_Bin_Data.append(Value)
            if len(current_Bin_Data) != 0:
                output_Bin_Data.append(sum(current_Bin_Data))
            if len(current_Bin_Data) == 0:
                output_Bin_Data.append(0)

        center_Bin = (np.array(Check_Bin[:-1])+np.array(Check_Bin[1:]))/2
        center_Bin[0] = Check_Bin[0]

        return center_Bin, np.array(output_Bin_Data)/sum(np.array(output_Bin_Data))



    bin_Size = 0.5
    alpha, delta = 0.9, 0.9
    main_path = './partner'
    #Color = ['b','r','g','k','m','y','b','r','g']
    energyThreshold = [-10, -7, -5, -3]
    energyThreshold = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
    all_paths = [main_path + '/fig_E'+str(eth) + '_a'+str(int(alpha*100))+'_d'+str(int(delta*100)) for eth in energyThreshold]


    ax = plt.subplot(4,2,1)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    classes_avg = []
    classes_std = []
    add1 = 0
    for eth, pathToPick, index_Color in zip(energyThreshold, all_paths, range(len(energyThreshold))):
        data = np.genfromtxt(pathToPick + '/ipr_class_no.dat')

        x_data, y_data = data[:,0], data[:,1]
        x_data, y_data = x_data, y_data/sum(y_data)

        classes_avg.append(sum(x_data*y_data))
        classes_std.append(sum(x_data**2*y_data) - sum(x_data*y_data)**2)

    ax.plot(energyThreshold, classes_avg, 'o', markersize=2.5, linewidth=0.5, color=mcolors.TABLEAU_COLORS['tab:gray'])
    for ind, avg, std in zip(energyThreshold, classes_avg, classes_std):
        ax.plot([ind+add1, ind+add1], [avg-std, avg+std], '-', markersize=3, linewidth=1.0, color=mcolors.TABLEAU_COLORS['tab:gray'])
        ax.plot([ind-0.15+add1, ind+0.15+add1], [avg-std, avg-std], '-', markersize=3, linewidth=1.0, color=mcolors.TABLEAU_COLORS['tab:gray'])
        ax.plot([ind-0.15+add1, ind+0.15+add1], [avg+std, avg+std], '-', markersize=3, linewidth=1.0, color=mcolors.TABLEAU_COLORS['tab:gray'])

    ax.tick_params(axis = 'x', which = 'minor', labelsize = fontticks)
    ax.set_xticks(energyThreshold, minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize = fontticks)
    ax.set_xticks(np.array(energyThreshold)[[0,2,4,6,8]], minor = False)

    ax.tick_params(axis = 'y', which = 'minor', labelsize = fontticks)
    ax.set_yticks(np.arange(2.0,12.0,1.0), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize = fontticks)
    ax.set_yticks(np.arange(2.0,12.5,2.0), minor = False)

    ax.set_ylabel(r'$ \langle {\mathrm{\# ~ classes}} \rangle $', fontsize=fontsizeY);
    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    #plt.text(1, 0.145, r'p(1-5)={}'.format(0.0), fontsize=8, alpha=0.85)
    ax.legend(ncol=2, loc='center', bbox_to_anchor=[0.6, 1.0], fontsize=fontticks, frameon=False)
    ax.set_title('{}'.format(Title[0]), loc='left', fontweight="bold")
    ax.set_xlim(-10.25,-1.75)
    ax.set_ylim(2.0,13.1)





    
    alpha, delta = 0.9, 0.9
    main_path = './partner'
    #Color = ['b','r','g','k']#'k',
    energyThreshold = [-10, -6, -2]
    all_paths = [main_path + '/fig_E'+str(eth) + '_a'+str(int(alpha*100))+'_d'+str(int(delta*100)) for eth in energyThreshold]

    ms1, lw1, mainlw1, mainelw1, sublw1, subelw1 = 1.5, 0.50, 0.0, 0.50, 0.0, 0.50
    ms2, lw2, mainlw2, mainelw2, sublw2, subelw2 = 2.0, 0.50, 0.0, 0.50, 0.0, 0.50
    ms3, lw3, mainlw3, mainelw3, sublw3, subelw3 = 2.0, 0.50, 0.0, 0.50, 0.0, 0.50
    ms4, lw4, mainlw4, mainelw4, sublw4, subelw4 = 2.0, 0.50, 0.0, 0.50, 0.0, 0.50
    ms5, lw5, mainlw5, mainelw5, sublw5, subelw5 = 2.0, 0.50, 0.0, 0.50, 0.0, 0.50
    ms6, lw6, mainlw6, mainelw6, sublw6, subelw6 = 2.0, 0.50, 0.0, 0.50, 0.0, 0.50

    alpha1, alpha2, alpha3, alpha4, alpha5, alpha6 = [0.4 for i in range(6)]
    subalpha1, subalpha2, subalpha3, subalpha4, subalpha5, subalpha6 = [0.2 for i in range(6)]


    bin_Size = 0.5 # all options are 0.5, 0.25
    typeOfGene = 'SLF'

    #ax = plt.subplot2grid((1,30), (0,0), rowspan=1, colspan=19)
    ax =  plt.subplot(4,2,3)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)
    ticks_Value = []

    for eth, pathToPick, index_Color in zip(energyThreshold, all_paths, range(len(energyThreshold))):
        data = np.genfromtxt(pathToPick + '/{}_degree.dat'.format(typeOfGene))
        x_data, y_data = data[:,0], data[:,1]/sum(data[:,1])
        x_data, y_data = bin_Control(x_data, y_data, bin_Size)

        for each_y_data, each_y_data_in in zip(y_data[::-1], list(range(len(y_data)))[::-1]):
            if np.round(each_y_data, decimals=3) > 0.001:
                y_last_non_zero = each_y_data_in + 1
                break

        print (x_data, y_data)

        if eth == -10:  y_data[2] = y_data[2]*1.0
        ax.plot(x_data[:y_last_non_zero], y_data[:y_last_non_zero], '-o', markersize=ms1, linewidth=lw1, color=Color[index_Color], label=r'$E_{\mathrm{th}}$='+'{}'.format(eth))
        plt.fill_between(x_data[:y_last_non_zero], -0.018, y_data[:y_last_non_zero], color=Color[index_Color], edgecolor='w', alpha=0.15)
        index_max = np.argmax(y_data) if np.argmax(y_data) != 0 else 1
        ax.plot([x_data[index_max]]*2, [-0.01, y_data[index_max]], '--', markersize=ms1, linewidth=lw1, color=Color[index_Color])

    ax.legend(ncol=1, bbox_to_anchor=[0.90, 0.90], fontsize=fontticks+1, frameon=False)
    Label='SLF' if typeOfGene == 'RNAse' else 'RNAse'
    ax.set_xlabel('Effective number of RNases \n detoxified by single SLF', fontsize=fontsizeX)
    ax.set_ylabel('Fraction', fontsize=fontsizeY)

    ax.tick_params(axis = 'x', which = 'minor', labelsize = 0)
    ax.set_xticks(np.arange(0,17,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(0,13,5), minor = False)


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,1,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,1.1,0.2), minor = False)
    ax.set_ylim([-0.018, 0.8])
    
    # ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    # ax.set_yticks(np.arange(0,1,0.05), minor = True)
    # ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    # ax.set_yticks(np.arange(0,1.1,0.2), minor = False)
    # ax.set_ylim([-0.025, 0.80])
    

    ax.set_xlim([-0.25, 13.25])
    ax.set_title(Title[1], loc='left', fontweight='bold')
    #plt.yscale('log')





    
    fourTypesAA = [0,1,2,3]
    SLF_No_data = 9
    length_RF = 18
    mul_factor = 10
    fontticks = fontticks

    color1, color2, color3 = mcolors.TABLEAU_COLORS['tab:green'], mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:gray']



    en_fraction = {}

    no_of_genes1, no_of_genes2 = 1500, 50
    EnergyValue = [-10, -9, -8, -7, -6, -5, -4, -3, -2]

    No_SLF1, No_SLF2, No_SLF3, No_SLF4 = no_of_genes1, no_of_genes1, no_of_genes1, no_of_genes1

    # random RNAse and random SLF from simulation weight
    # ---------------
    tempRNAse = [np.random.choice(fourTypesAA, length_RF, p=weight) for i in range(no_of_genes2)]
    for RNAse in tempRNAse:
        for trial in range(No_SLF2):
            inter_Energy = energyOfIntPair(RNAse, np.random.choice(fourTypesAA, length_RF, p=weight))

            if inter_Energy in list(en_fraction.keys()):
                en_fraction[inter_Energy] += 1
            else:
                en_fraction[inter_Energy] = 1

    random_energy = list(en_fraction.keys())
    energy_Count = list(en_fraction.values())
    sorted_index = np.argsort(random_energy)
    total_sum = sum(energy_Count)
    random_energy, energy_Count = np.array(random_energy), np.array(energy_Count)
    energy_Unique, energy_Count = random_energy[sorted_index], energy_Count[sorted_index]
    energy_Count = energy_Count/total_sum

    #Index_Th = np.where(energy_Unique == energyThreshold)[0][0]
    #sum_PE = np.round(np.sum(energy_Count[:Index_Th]), decimals=3)

    mul_factor = 10
    for ix in [8]:

        ax = plt.subplot(4, 2, ix)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)

        ax.plot(energy_Unique, energy_Count*mul_factor, '-o', color=color3, ms=1.5, linewidth=0.5)

        ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax.set_yticks(np.arange(0,0.051*mul_factor,0.005*mul_factor), minor = True)
        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_yticks(np.arange(0,0.05*mul_factor,0.02*mul_factor), minor = False)

        #ax.set_title('{}'.format(Title[ix-3]), loc='left', fontweight="bold")
        ax.set_xlabel(r'$E_{\mathrm{tot}}$', fontsize=fontsizeX)


        ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
        ax.set_xticks(np.arange(-14,2.75,1), minor = True)
        ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax.set_xticks(np.arange(-10,2.75,5), minor = False)

        ax.set_xlim([np.min(energy_Unique)-0.75, np.max(energy_Unique)+0.75])
        ax.set_ylim([-0.0020*mul_factor,0.0505*mul_factor])


        for eth, height_y in zip([-10, -6, -2], [0.1, 0.5, 0.1]):
            ax.plot([eth]*100, np.linspace(-0.0225, mul_factor*en_fraction[eth]/total_sum, 100), '--', color=color3, linewidth=0.5)
            if eth == -10:
                ax.text(eth-6.5, height_y, r'$E_{\mathrm{th}} = $' + '{}'.format(eth), fontsize=fontsizeX-1.75)
            elif eth == -6:
                ax.text(eth-7.5, 0.38, r'$E_{\mathrm{th}} = $' + '{}'.format(eth), fontsize=fontsizeX-1.75)
            else:
                ax.text(eth+0.5, height_y, r'$E_{\mathrm{th}} = $' + '{}'.format(eth), fontsize=fontsizeX-1.75)
                'do nothing'
            #index_eth = list(energy_Unique).index(eth)
            #ax.fill_between(energy_Unique[:index_eth], -0.001, energy_Count[:index_eth], color=color3, edgecolor='w', alpha=0.15)

        #ax.legend([r'random'], loc=1, frameon=False, fontsize=fontticks)
        #ax.set_title('random', loc='right', fontsize=fontsizeX)
        ax.text(0, 0.485, 'neutral', fontsize=fontsizeX)
        ax.set_ylabel(r'Fraction $(\times 10^{-1})$', fontsize=fontsizeX)



        ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
        ax.set_xticks(np.arange(-16,8.1,1), minor = True)
        ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax.set_xticks(np.arange(-15,8.1,5), minor = False)

        ax.set_xlim([-16.75,8.25])






    energy_Unique_random, energy_Count_random = energy_Unique, energy_Count


    for ix, eth, ix_temp in zip([2, 4, 6], [-10, -6, -2], [0, 1, 2]):
        ax = plt.subplot(4, 2, ix)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)

        #color2 = 'k' #Color[ix_temp]


        specific_Energy = np.genfromtxt('./partner/specific_energy_eth/specific_energy_eth_{}.dat'.format(eth))
        sorted_index = np.argsort(specific_Energy[:,0])

        energy_Unique, energy_Count = specific_Energy[:,0][sorted_index], specific_Energy[:,1][sorted_index]
        energy_Unique = list(energy_Unique)
        energy_Count = energy_Count/sum(energy_Count)

        max_at_eth = 0
        for v_eth, v_value in zip(energy_Unique, energy_Count):
            if v_eth == eth:    max_at_eth = v_value
        ax.plot(energy_Unique, energy_Count*mul_factor, '-o', color=color2, ms=1.5, linewidth=0.5)
        ax.plot([eth]*100, np.linspace(-0.0225, mul_factor*max_at_eth, 100), '--', color=color2, linewidth=0.5)

        #max_at_eth = 0
        #for v_eth, v_value in zip(energy_Unique_random, energy_Count_random):
        #    if v_eth == eth:    max_at_eth = v_value
        #ax.plot(energy_Unique_random, energy_Count_random*mul_factor, '-o', color=color3, ms=1.5, linewidth=0.5)
        #ax.plot([eth]*100, np.linspace(-0.0010, mul_factor*max_at_eth, 100), '--', color=color3, linewidth=0.5)

        ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax.set_yticks(np.arange(0,0.051*mul_factor,0.005*mul_factor), minor = True)
        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_yticks(np.arange(0,0.05*mul_factor,0.02*mul_factor), minor = False)

        if eth == -10:  ax.set_title('{}'.format(Title[2]), loc='left', fontweight="bold")
        ax.set_xlabel(r'$E_{\mathrm{tot}}$', fontsize=fontsizeX)

        index_eth = energy_Unique.index(eth)
        ax.fill_between(energy_Unique[:index_eth], -0.0225, energy_Count[:index_eth]*mul_factor, color=color2, edgecolor='w', alpha=0.15)
        #ax.fill_between(energy_Unique[index_eth-1:], -0.001, energy_Count[index_eth-1:], color=color3, hatch='//////////', edgecolor='w', alpha=1)

        ax.set_ylabel(r'Fraction $(\times 10^{-1})$', fontsize=fontsizeX, labelpad=1.5)
        #ax.legend([r'$E_{\mathrm{th}} = $' + '{}'.format(eth)], loc=2, frameon=False, fontsize=fontticks)
        #ax.set_title(r'$E_{\mathrm{th}} = $' + '{}'.format(eth), loc='center', fontsize=fontticks)

        if eth == -10:

            ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
            ax.set_xticks(np.arange(-15,2.75,1), minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks(np.arange(-15,2.75,5), minor = False)

            ax.set_xlim([-16.75,2.75])
            ax.set_ylim([-0.00125*mul_factor,0.046*mul_factor])

            #ax.legend([r'$E_{\mathrm{th}} = $' + '{}'.format(eth)], loc=1, frameon=False, fontsize=fontticks)
            #ax.set_title(r'$E_{\mathrm{th}} = $' + '{}'.format(eth), loc='right', fontsize=fontsizeX)
            ax.text(1, 0.485, r'$E_{\mathrm{th}} = $' + '{}'.format(eth), fontsize=fontsizeX)


        if eth == -6:

            ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
            ax.set_xticks(np.arange(-15,5.75,1), minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks(np.arange(-15,5.75,5), minor = False)

            ax.set_xlim([-17.00,5.78])
            ax.set_ylim([-0.00125*mul_factor,0.052*mul_factor])

            #ax.legend([r'$E_{\mathrm{th}} = $' + '{}'.format(eth)], loc=2, frameon=False, fontsize=fontticks)
            #ax.set_title(r'$E_{\mathrm{th}} = $' + '{}'.format(eth), loc='right', fontsize=fontsizeX)
            ax.text(1, 0.485, r'$E_{\mathrm{th}} = $' + '{}'.format(eth), fontsize=fontsizeX)

        if eth == -2:

            ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
            ax.set_xticks(np.arange(-15,7.75,1), minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks(np.arange(-15,5.75,5), minor = False)

            ax.set_xlim([-13.50,8.0])
            ax.set_ylim([-0.00125*mul_factor,0.052*mul_factor])

            #ax.legend([r'$E_{\mathrm{th}} = $' + '{}'.format(eth)], loc=2, frameon=False, fontsize=fontticks)
            #ax.set_title(r'$E_{\mathrm{th}} = $' + '{}'.format(eth), loc='right', fontsize=fontsizeX)
            ax.text(1, 0.485, r'$E_{\mathrm{th}} = $' + '{}'.format(eth), fontsize=fontsizeX)



        ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
        ax.set_xticks(np.arange(-15,8.1,1), minor = True)
        ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax.set_xticks(np.arange(-15,8.1,5), minor = False)

        ax.set_xlim([-16.75,8.25])



    #plt.tight_layout()
    plt.savefig('Figure_2.pdf'.format(energyThreshold), transparent=True)
    #plt.show()
    plt.close()

    return 'done'


print (plot_unique_Gene_Paper(0))



print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
