#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
from numba import jit # type: ignore
import pickle
from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
from operator import itemgetter
#from scipy.integrate import odeint
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes) # type: ignore
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import matplotlib as mpl # type: ignore
import seaborn as sns # type: ignore
from matplotlib.ticker import FormatStrFormatter # type: ignore
import matplotlib.colors as mcolors  # type: ignore
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

energy_interaction = np.array([[-1,0,0,0],[0,-0.75,-0.25,-0.25],[0,-0.25,1,-1.25],[0,-0.25,-1.25,1]])
#@jit(nopython=True)
def energyOfIntPair(RNAse, FBoxg):  return sum([energy_interaction[int(x),int(y)] for x, y in zip(RNAse, FBoxg)])
def HammingDistance(inputX, inputY):
    hDistance = 0
    for x, y in zip(inputX, inputY):
        if x != y: hDistance += 1
    return hDistance

weight = [0.5, 0.265, 0.113, 0.122]
def plot_unique_Gene_Paper(input_Var):

    plt.figure(figsize=(8,2.5))
    plt.subplots_adjust(top=0.91, bottom=0.143, left=0.052, right=0.996, hspace=0.414, wspace=0.15)


    fontsizeX, fontsizeY, fonttitle, fontticks = 8, 8, 8, 6
    AminoAcid = ['H', 'P', '+', '-']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m'];
    EnergyValue = [-7, -3]



    Samples = 25

    def bin_Control(input_Var_1, input_Var_2, binSize):
        data_X, data_Y = input_Var_1, input_Var_2

        Check_Bin = [0]  # corresponds to first bin [0 - firstBinEnd)
        for i in range(int(np.max(data_X)/(2*binSize)) + 2):
            if i == 0:
                Check_Bin.append(Check_Bin[-1]+binSize)
            else:
                Check_Bin.append(Check_Bin[-1]+2*binSize)

        output_Bin_Data = []; center_Bin = []; bib_Interval = binSize

        for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
            current_Bin_Data = []
            for Key, Value in zip(data_X, data_Y):
                if Key >= bin1 and Key < bin2:
                    current_Bin_Data.append(Value)
            if len(current_Bin_Data) != 0:
                output_Bin_Data.append(sum(current_Bin_Data))
            if len(current_Bin_Data) == 0:
                output_Bin_Data.append(0)

        center_Bin = (np.array(Check_Bin[:-1])+np.array(Check_Bin[1:]))/2
        center_Bin[0] = Check_Bin[0]

        return center_Bin, np.array(output_Bin_Data)/sum(np.array(output_Bin_Data))



    #plt.figure(figsize=(8,2.5))
    #plt.subplots_adjust(top=0.91, bottom=0.143, left=0.052, right=0.996, hspace=0.414, wspace=0.265) # in case three panels
    plt.figure(figsize=(6,5.0))
    plt.subplots_adjust(top=0.955, bottom=0.069, left=0.071, right=0.993, hspace=0.389, wspace=0.260)


    fontsizeX, fontsizeY, fonttitle, fontticks = 8, 8, 8, 6
    AminoAcid = ['H', 'P', '+', '-']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m'];



    alpha, delta = 0.9, 0.9

    color1, color2, color3 = mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:red'], mcolors.TABLEAU_COLORS['tab:green']





    ax =  plt.subplot(2,2,2)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    data_to_plot = []
    marginal_data = []
    file_path = './local_global/joint_aa_fre'
    energyThreshold = [-10, -6, -2]
    eth_dict = {eth_v:i for eth_v, i in zip(range(-10,-1), range(9))}

    for eth in energyThreshold:
        marginal_rnase = np.genfromtxt(file_path + '/marginal_rnases_aa.dat')[eth_dict[eth]]
        marginal_slf = np.genfromtxt(file_path + '/marginal_slfs_aa.dat')[eth_dict[eth]]
        avoind_sc_joint = np.genfromtxt(file_path + '/joint_selfslfs_aa_e{}.dat'.format(eth))
        finding_com_joint = np.genfromtxt(file_path + '/joint_nonself_interslfs_aa_e{}.dat'.format(eth))

        #print (marginal_rnase, 'marginal rnase')
        #print (marginal_slf, 'marginal slf', '\n', '\n', '\n', '\n')

        #print (avoind_sc_joint[2]/sum(avoind_sc_joint[2]))
        #print (finding_com_joint[2]/sum(finding_com_joint[2]), '\n', '\n', '\n', '\n')

        #print (marginal_rnase[2]*marginal_slf/sum(marginal_rnase[2]*marginal_slf), marginal_rnase[3]*marginal_slf/sum(marginal_rnase[3]*marginal_slf))

        marginal_data.append(marginal_slf[2])
        marginal_data.append(marginal_slf[3])
        for aa_ind in [2]:
            #print (avoind_sc_joint[aa_ind]/sum(avoind_sc_joint[aa_ind]))
            #print (finding_com_joint[aa_ind]/sum(finding_com_joint[aa_ind]), '\n', '\n', '\n', '\n')
            data_to_plot.append((avoind_sc_joint[aa_ind]/sum(avoind_sc_joint[aa_ind]))[-2])
            data_to_plot.append((avoind_sc_joint[aa_ind]/sum(avoind_sc_joint[aa_ind]))[-1])
            data_to_plot.append((finding_com_joint[aa_ind]/sum(finding_com_joint[aa_ind]))[-2])
            data_to_plot.append((finding_com_joint[aa_ind]/sum(finding_com_joint[aa_ind]))[-1])
        #print (eth, '\n')

    data_to_plot = data_to_plot
    #print (len(data_to_plot), '-----')
    #print (marginal_data)

    x_data = [1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14]
    for ind in range(len(x_data)):
        if ind in [0, 1, 4, 5, 8, 9]:
            if ind == range(len(x_data))[-3]:
                plt.bar(x_data[ind:ind+1], data_to_plot[ind:ind+1], width=0.35, color=color2, alpha=0.75, label='self')
            else:
                plt.bar(x_data[ind:ind+1], data_to_plot[ind:ind+1], width=0.35, color=color2, alpha=0.75)
        else:
            if ind == range(len(x_data))[-1]:
                plt.bar(x_data[ind:ind+1], data_to_plot[ind:ind+1], width=0.35, color=color1, alpha=0.75, label='partner')
            else:
                plt.bar(x_data[ind:ind+1], data_to_plot[ind:ind+1], width=0.35, color=color1, alpha=0.75)

    color = ['k', 'r', 'c']
    for eth, eth_ind in zip(energyThreshold, range(len(energyThreshold))):
        plt.plot([x_data[4*eth_ind]-0.50, x_data[4*(eth_ind+1)-1]+0.50], [marginal_data[2*eth_ind], marginal_data[2*eth_ind]], '-', linewidth=0.75, color=color[0])#, \
                    #label=r'marginal $p_{\mathrm{SLF}}({\mathrm{+}})$, $E_{\mathrm{th}} = $' + str(eth))
        plt.plot([x_data[4*eth_ind]-0.50, x_data[4*(eth_ind+1)-1]+0.50], [marginal_data[2*eth_ind+1], marginal_data[2*eth_ind+1]], '--', linewidth=0.75, color=color[0])#, \
                    #label=r'marginal $p_{\mathrm{SLF}}({\mathrm{-}})$, $E_{\mathrm{th}} = $' + str(eth))


    plt.legend(ncols=1, fontsize=fontticks+1, frameon=False, loc=1)#, bbox_to_anchor = [0.6, 0.55])
    ax.set_ylabel(r'$Pr(*_{\mathrm{SLF}} | +_{\mathrm{RNase}})$', fontsize=fontsizeX)
    #ax.set_xlabel('    self           partner              self        partner\n' + \
    #                r'$E_{\mathrm{th}} = -10$                        $E_{\mathrm{th}} = -2$', fontsize=fontsizeY, labelpad=4.4)
    ax.set_xlabel(r'$E_{\mathrm{th}} = -10$          $E_{\mathrm{th}} = -6$          $E_{\mathrm{th}} = -2$', fontsize=fontsizeY)

    ax.tick_params(axis = 'y', which = 'minor', labelsize=0)
    ax.set_yticks(np.arange(0,0.53,0.02), minor = True)

    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.51,0.1), minor = False)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
    ax.set_xticks(x_data, ['+|+', '-|+']*6, minor = False)

    ax.set_ylim([-0.0, 0.525])
    ax.set_xlim([0.25, 14.75])
    ax.set_title(Title[1], loc='left', fontweight='bold')










    EnergyValue = [-10, -9, -8, -7, -6, -5, -4, -3, -2]



    weight_RNAse_Data = np.array([[0.3403, 0.3567, 0.1596, 0.1434],\
                                  [0.335,  0.3314, 0.1616, 0.172 ],\
                                  [0.3046, 0.2887, 0.1907, 0.2161],\
                                  [0.271,  0.295,  0.2045, 0.2295],\
                                  [0.2209, 0.2946, 0.229,  0.2555],\
                                  [0.2031, 0.2681, 0.2376, 0.2912],\
                                  [0.1717, 0.2576, 0.2619, 0.3087],\
                                  [0.1297, 0.2392, 0.2985, 0.3326],\
                                  [0.0958, 0.2042, 0.3178, 0.3822]])

    weight_SLF_Data = np.array([[0.467,  0.306,  0.1004, 0.1265],\
                                [0.4684, 0.2966, 0.1153, 0.1197],\
                                [0.4732, 0.3013, 0.1136, 0.1119],\
                                [0.4568, 0.3081, 0.1165, 0.1185],\
                                [0.4656, 0.2901, 0.119,  0.1253],\
                                [0.4826, 0.2795, 0.1169, 0.121 ],\
                                [0.4945, 0.2621, 0.116,  0.1274],\
                                [0.5062, 0.2545, 0.1134, 0.126 ],\
                                [0.5105, 0.2425, 0.1146, 0.1324]])

    print (weight_RNAse_Data)
    print (weight_SLF_Data)



    weight_slfs_RNAse_Data = np.array([[0.3320, 0.2562, 0.2067, 0.2052],\
                                       [0.2580, 0.2331, 0.2352, 0.2737],\
                                       [0.2151, 0.2307, 0.2614, 0.2928],\
                                       [0.1749, 0.2415, 0.2818, 0.3018],\
                                       [0.1137, 0.2141, 0.3093, 0.3629],\
                                       [0.0958, 0.2042, 0.3178, 0.3822]])

    weight_slfs_SLF_Data = np.array([[0.4960, 0.3414, 0.0808, 0.0818],\
                                     [0.4775, 0.3008, 0.1083, 0.1135],\
                                     [0.4818, 0.2796, 0.1146, 0.1240],\
                                     [0.4961, 0.2572, 0.1176, 0.1291],\
                                     [0.5022, 0.2454, 0.1170, 0.1354],\
                                     [0.5105, 0.2425, 0.1146, 0.1324]])



    rnase_entropy = []
    for rnase_weight in weight_RNAse_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, weight)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight in weight_SLF_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, weight)]
        slf_entropy.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '\n \n')





    path = './local_global/joint_aa_fre'

    partner_joint = []
    slf_margi_partner = []
    rnase_margi_partner = []

    self_joint = []
    slf_margi_self = []
    rnase_margi_self = []

    for eth in EnergyValue[:]:
        partner = np.genfromtxt(path + '/joint_nonself_interslfs_aa_e{}.dat'.format(eth))
        partner = partner/np.sum(partner)

        slf_margi_partner.append(np.sum(partner, axis=0)) # axis = 0 for SLF marginal
        rnase_margi_partner.append(np.sum(partner, axis=1)) # axis = 1 for RNase marginal
        partner_joint.append(partner.flatten())

        self = np.genfromtxt(path + '/joint_selfslfs_aa_e{}.dat'.format(eth))
        self = self/np.sum(self)

        slf_margi_self.append(np.sum(self, axis=0)) # axis = 0 for SLF marginal
        rnase_margi_self.append(np.sum(self, axis=1)) # axis = 1 for RNase marginal
        self_joint.append(self.flatten())


    partner_joint = np.array(partner_joint)
    slf_margi_partner = np.array(slf_margi_partner)
    rnase_margi_partner = np.array(rnase_margi_partner)

    self_joint = np.array(self_joint)
    slf_margi_self = np.array(slf_margi_self)
    rnase_margi_self = np.array(rnase_margi_self)


    #print (partner_joint, '\n')
    #print (slf_margi_partner, '\n')
    #print (rnase_margi_partner, '\n', '\n', '\n')

    #print (self_joint, '\n')
    #print (slf_margi_self, '\n')
    #print (rnase_margi_self, '\n')



    def k_dl_fun(rnase_margi, slf_margi, joint):
        final_divergent = []
        for r_mar, s_mar, p_cond in zip(rnase_margi, slf_margi, joint):
            divergent = []
            for each_ele, ind in zip(p_cond, range(len(p_cond))):
                r_ind, s_ind = ind//4, ind%4
                entropy = each_ele*np.log(each_ele/(r_mar[r_ind]*s_mar[s_ind]))
                divergent.append(entropy)
                #print (each_ele, ind)

            final_divergent.append(sum(divergent))

        return np.round(final_divergent, decimals=3)



    rnase_margi, slf_margi, joint = rnase_margi_partner, slf_margi_partner, partner_joint
    partner_div =  k_dl_fun(rnase_margi, slf_margi, joint)

    rnase_margi, slf_margi, joint = rnase_margi_self, slf_margi_self, self_joint
    self_diver =  k_dl_fun(rnase_margi, slf_margi, joint)

    print (partner_div)
    print (self_diver)
    print (partner_div + self_diver)




    color1, color2, color3 = mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:red'], mcolors.TABLEAU_COLORS['tab:gray']
    ms=3.5

    ax = plt.subplot(2, 2, 1)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    plt.plot(EnergyValue, self_diver, '-o', color=color2, ms=ms, linewidth=0.5)
    plt.plot(EnergyValue, partner_div, '-o', color=color1, ms=ms, linewidth=0.5)


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.825,0.025), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.825,0.1), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(-10,-1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(-10,-1,2), minor = False)

    ax.set_title('{}'.format(Title[0]), loc='left', fontweight="bold")
    ax.set_xlabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}$(P || Q), Q = marginal', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\varphi^{({\mathrm{RNase, SLF}})} ~|| ~\psi^{{\mathrm{RNase}}} \times \psi^{{\mathrm{SLF}}})$  [nat]', fontsize=fontsizeX-1)
    #ax.legend([r'self, $\phi_{\mathrm{RNase,SLF}}$', r'partner, $\phi_{\mathrm{RNase,SLF}}$'], frameon=False, fontsize=fontticks+1)
    #ax.legend([r'$\varphi^{\mathrm{self}}$', r'$\varphi^{\mathrm{partner}}$'], frameon=False, fontsize=fontticks+1)
    ax.legend([r'self', r'partner'], frameon=False, fontsize=fontticks+1)
    ax.set_xlim([-10.4,-1.7])
    ax.set_ylim([-0.010,0.26])






    ax = plt.subplot(2, 2, 3)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    #plt.plot(EnergyValue, self_diver, '-o', color=color2, ms=ms, linewidth=0.5)
    plt.plot(EnergyValue, partner_div, '-o', color=color1, ms=ms, linewidth=0.5)


    # ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    # ax.set_yticks(np.arange(0,0.825,0.025), minor = True)
    # ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    # ax.set_yticks(np.arange(0,0.825,0.1), minor = False)

    # ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    # ax.set_xticks(np.arange(-10,-1,1), minor = True)
    # ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    # ax.set_xticks(np.arange(-10,-1,2), minor = False)

    ax.set_title('{}'.format(Title[2]), loc='left', fontweight="bold")
    ax.set_xlabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}$(P || Q), Q = marginal', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}$ [nat]', fontsize=fontsizeX-1)
    #ax.legend([r'self, $\phi_{\mathrm{RNase,SLF}}$', r'partner, $\phi_{\mathrm{RNase,SLF}}$'], frameon=False, fontsize=fontticks+1)
    #ax.legend([r'$\varphi^{\mathrm{self}}$', r'$\varphi^{\mathrm{partner}}$'], frameon=False, fontsize=fontticks+1)
    #ax.legend([r'$D_{\mathrm{KL}}(\varphi^{({\mathrm{RNase, SLF}})} ~|| ~\psi^{{\mathrm{RNase}}} \times \psi^{{\mathrm{SLF}}})$, partner'], frameon=False, fontsize=fontticks)
    #ax.set_xlim([-10.4,-1.7])
    #ax.set_ylim([-0.010,0.26])






    weight_RNAse_Data = np.array([[0.3403, 0.3567, 0.1596, 0.1434],\
                                  [0.335,  0.3314, 0.1616, 0.172 ],\
                                  [0.3046, 0.2887, 0.1907, 0.2161],\
                                  [0.271,  0.295,  0.2045, 0.2295],\
                                  [0.2209, 0.2946, 0.229,  0.2555],\
                                  [0.2031, 0.2681, 0.2376, 0.2912],\
                                  [0.1717, 0.2576, 0.2619, 0.3087],\
                                  [0.1297, 0.2392, 0.2985, 0.3326],\
                                  [0.0958, 0.2042, 0.3178, 0.3822]])

    weight_SLF_Data = np.array([[0.467,  0.306,  0.1004, 0.1265],\
                                [0.4684, 0.2966, 0.1153, 0.1197],\
                                [0.4732, 0.3013, 0.1136, 0.1119],\
                                [0.4568, 0.3081, 0.1165, 0.1185],\
                                [0.4656, 0.2901, 0.119,  0.1253],\
                                [0.4826, 0.2795, 0.1169, 0.121 ],\
                                [0.4945, 0.2621, 0.116,  0.1274],\
                                [0.5062, 0.2545, 0.1134, 0.126 ],\
                                [0.5105, 0.2425, 0.1146, 0.1324]])


    color1, color2, color3, color4 = mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:red'], \
                                        mcolors.TABLEAU_COLORS['tab:gray'], mcolors.TABLEAU_COLORS['tab:cyan']


    rnase_entropy = []
    for rnase_weight in weight_RNAse_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, weight)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight in weight_SLF_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, weight)]
        slf_entropy.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '\n \n')


    plt.plot(EnergyValue, rnase_entropy, '-o', color=color3, ms=ms, linewidth=0.5)
    #plt.plot(EnergyValue, slf_entropy, '-o', color=color2, ms=ms, linewidth=0.5)


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.825,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.825,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(-10,-1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(-10,-1,2), minor = False)

    #ax.set_title('{}'.format(Title[1]), loc='left', fontweight="bold")
    #ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}(\psi || \nu), \nu = $prior', fontsize=fontsizeX)
    #ax.legend([r'$\psi^{\mathrm{RNase}}$', r'$\psi^{\mathrm{SLF}}$'], frameon=False, fontsize=fontticks+1)
    #ax.legend([r'$D_{\mathrm{KL}}(\varphi^{({\mathrm{RNase, SLF}})} ~|| ~\psi^{{\mathrm{RNase}}} \times \psi^{{\mathrm{SLF}}})$, partner', \
    #           r'$D_{\mathrm{KL}}(\psi ~||~ \nu), \nu = $prior'], frameon=False, fontsize=fontticks+1)
    ax.legend([r'local: RNase-SLF attraction', r'global: RNase repulsion'], frameon=False, fontsize=fontticks+1)

    ax.set_xlim([-10.4,-1.7])
    ax.set_ylim([-0.020,0.9])



    plt.savefig('Figure_6.pdf'.format(energyThreshold), transparent=True)
    #plt.show()
    plt.close()

    return 'done'


print (plot_unique_Gene_Paper(0))


print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
