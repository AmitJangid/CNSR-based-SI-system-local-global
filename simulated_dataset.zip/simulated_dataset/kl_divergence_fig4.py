#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
from numba import jit # type: ignore
import pickle
from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import seaborn as sns # type: ignore
import matplotlib.colors as mcolors  # type: ignore
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes)  # type: ignore
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

weight = [0.5, 0.265, 0.113, 0.122]

energy_interaction = np.array([[-1,0,0,0],[0,-0.75,-0.25,-0.25],[0,-0.25,1,-1.25],[0,-0.25,-1.25,1]])
def energyOfIntPair(RNAse, FBoxg):  return sum([energy_interaction[x,y] for x, y in zip(RNAse.astype(int), FBoxg.astype(int))])

#
#
#
#############
def plot_prob_AA_Paper(input_Var): # Box plot
    print (mcolors.TABLEAU_COLORS)
    color1, color2, color3 = mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:red'], mcolors.TABLEAU_COLORS['tab:gray']
    #color1, color2, color3 = mcolors.TABLEAU_COLORS['tab:gray'], mcolors.TABLEAU_COLORS['tab:green'], mcolors.TABLEAU_COLORS['tab:orange']

    EnergyValue = [-10, -9, -8, -7, -6, -5, -4, -3, -2]

    textTitle_RNAse_Y = [0.40,0.42,0.4,0.45]
    textTitle_RNAse_X = [(len(EnergyValue)+1.0)/2, (len(EnergyValue)+0.6)/2, (len(EnergyValue)-1)/2, (len(EnergyValue)+0.5)/4]

    textTitle_SLF_Y = [0.33,0.4,0.2,0.2]
    textTitle_SLF_X = [(len(EnergyValue)-1.5)*2, (len(EnergyValue)-1.5)*2, (len(EnergyValue)-1.5)*2, (len(EnergyValue)-1.5)*2]

    gen_Index = [0, 1]
    fontsizeX, fontsizeY, fonttitle, fontticks = 8, 8, 8, 6
    AminoAcid = ['H', 'P', '+', '-']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];
    my_colors = ['k', 'k', 'k', 'k', 'k', 'k', 'k','k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k']
    my_colors_Box = ['w', 'w', 'w', 'w', 'w', 'w', 'w','w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w','w', 'w']
    ms=3.5


    # for different eth = [-10 .. -2]
    weight_RNAse_Data = np.array([[0.3403, 0.3567, 0.1596, 0.1434],\
                                  [0.335,  0.3314, 0.1616, 0.172 ],\
                                  [0.3046, 0.2887, 0.1907, 0.2161],\
                                  [0.271,  0.295,  0.2045, 0.2295],\
                                  [0.2209, 0.2946, 0.229,  0.2555],\
                                  [0.2031, 0.2681, 0.2376, 0.2912],\
                                  [0.1717, 0.2576, 0.2619, 0.3087],\
                                  [0.1297, 0.2392, 0.2985, 0.3326],\
                                  [0.0958, 0.2042, 0.3178, 0.3822]])

    weight_SLF_Data = np.array([[0.467,  0.306,  0.1004, 0.1265],\
                                [0.4684, 0.2966, 0.1153, 0.1197],\
                                [0.4732, 0.3013, 0.1136, 0.1119],\
                                [0.4568, 0.3081, 0.1165, 0.1185],\
                                [0.4656, 0.2901, 0.119,  0.1253],\
                                [0.4826, 0.2795, 0.1169, 0.121 ],\
                                [0.4945, 0.2621, 0.116,  0.1274],\
                                [0.5062, 0.2545, 0.1134, 0.126 ],\
                                [0.5105, 0.2425, 0.1146, 0.1324]])

    print (weight_RNAse_Data)
    print (weight_SLF_Data)


    # number of slfs per haplotype [1, 2, 3, 4, 7, 9] for eth = -2
    weight_slfs_RNAse_Data = np.array([[0.3320, 0.2562, 0.2067, 0.2052],\
                                       [0.2580, 0.2331, 0.2352, 0.2737],\
                                       [0.2151, 0.2307, 0.2614, 0.2928],\
                                       [0.1749, 0.2415, 0.2818, 0.3018],\
                                       [0.1137, 0.2141, 0.3093, 0.3629],\
                                       [0.0958, 0.2042, 0.3178, 0.3822]])

    weight_slfs_SLF_Data = np.array([[0.4960, 0.3414, 0.0808, 0.0818],\
                                     [0.4775, 0.3008, 0.1083, 0.1135],\
                                     [0.4818, 0.2796, 0.1146, 0.1240],\
                                     [0.4961, 0.2572, 0.1176, 0.1291],\
                                     [0.5022, 0.2454, 0.1170, 0.1354],\
                                     [0.5105, 0.2425, 0.1146, 0.1324]])



    plt.figure(figsize=(8,4.25))
    plt.subplots_adjust(top=0.949, bottom=0.080, left=0.054, right=0.995, hspace=0.5, wspace=0.323)

    
    ax = plt.subplot(2,3,1)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    energy_interaction = np.array([[-1,0,0,0],[0,-0.75,-0.25,-0.25],[0,-0.25,1,-1.25],[0,-0.25,-1.25,1]])
    def energyOfIntPair(RNAse, FBoxg):  return sum([energy_interaction[int(x),int(y)] for x, y in zip(RNAse, FBoxg)])

    E_Th = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
    fourTypesAA = [0,1,2,3]
    SLF_No_data = 9
    length_RF = 18
    pathToSave = '../../the_old_simulation/lowSLF/figures'

    fraction = []

    no_of_genes1, no_of_genes2 = 2000, 50

    No_SLF1, No_SLF2, No_SLF3, No_SLF4 = no_of_genes1, no_of_genes1, no_of_genes1, no_of_genes1

    # random RNAse and random SLF from simulation weight
    # ---------------
    tempRNAse = [np.random.choice(fourTypesAA, length_RF, p=weight) for i in range(no_of_genes2)]
    energy = {}
    for RNAse in tempRNAse:
        for trial in range(No_SLF2):
            inter_Energy = energyOfIntPair(RNAse, np.random.choice(fourTypesAA, length_RF, p=weight))

            if inter_Energy in list(energy.keys()):
                energy[inter_Energy] += 1
            else:
                energy[inter_Energy] = 1


    random_energy = list(energy.keys())
    energy_Count = list(energy.values())
    sorted_index = np.argsort(random_energy)
    total_sum = sum(energy_Count)
    random_energy, energy_Count = np.array(random_energy), np.array(energy_Count)
    energy_Unique, energy_Count = random_energy[sorted_index], energy_Count[sorted_index]
    energy_Count = energy_Count/total_sum

    #energy_Unique, energy_Count = np.unique(energy, return_counts=True)
    #energy_Count = energy_Count/sum(energy_Count)

    for energyThreshold, plot_index in zip(E_Th, range(len(E_Th))):

        Index_Th = np.where(energy_Unique == energyThreshold)[0][0]
        sum_PE = np.round(np.sum(energy_Count[:Index_Th]), decimals=3)
        fraction.append(sum_PE)

    plt.plot(E_Th, fraction, '-o', color=color1, markersize=ms, linewidth=0.5)
    print (E_Th, fraction, 'random')


    fraction = []

    for energyThreshold, plot_index in zip(E_Th, range(len(E_Th))):
        #ax = plt.subplot2grid((100,100), (int(plot_index/3)*25, plot_index%3*33), colspan=27, rowspan=20)
        #specific_Energy = np.genfromtxt(pathToSave+'/specific_energy/specific_Energy_E{}_{}SLF.dat'.format(energyThreshold, SLF_No_data))
        specific_Energy = np.genfromtxt('./partner/specific_energy_eth/specific_energy_eth_{}.dat'.format(energyThreshold))
        sorted_index = np.argsort(specific_Energy[:,0])

        # ---------------
        energy_Unique, energy_Count = specific_Energy[:,0][sorted_index], specific_Energy[:,1][sorted_index]
        energy_Count = energy_Count/sum(energy_Count)

        Index_Th = np.where(energy_Unique == energyThreshold)[0][0]
        sum_PE = np.round(np.sum(energy_Count[:Index_Th]), decimals=3)
        fraction.append(sum_PE)

        #plt.bar(energy_Unique, energy_Count, width=0.25)
        #plt.plot([energyThreshold]*10, [i/200 for i in range(10)], 'k--')
        #plt.text(energyThreshold+1,0.045,sum_PE, color='k', fontsize=8)
    plt.plot(E_Th, fraction, '-o', color=color2, markersize=ms, linewidth=0.5)
    print (E_Th, fraction, 'evolved')




    E_Th = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
    fourTypesAA = [0,1,2,3]

    fraction = []

    No_SLF1, No_SLF2, No_SLF3, No_SLF4 = no_of_genes1, no_of_genes1, no_of_genes1, no_of_genes1
    for energyThreshold, plot_index, weight_RNAse, weight_SLF in zip(E_Th, range(len(E_Th)), weight_RNAse_Data, weight_SLF_Data):

        weight_RNAse = weight_RNAse/sum(weight_RNAse)
        weight_SLF = weight_SLF/sum(weight_SLF)

        # random RNAse and random SLF from simulation weight
        # ---------------
        tempRNAse = [np.random.choice(fourTypesAA, length_RF, p=weight_RNAse) for i in range(no_of_genes2)]
        energy = {}
        for RNAse in tempRNAse:
            for trial in range(No_SLF2):
                inter_Energy = energyOfIntPair(RNAse, np.random.choice(fourTypesAA, length_RF, p=weight_SLF))
                if inter_Energy in list(energy.keys()):
                    energy[inter_Energy] += 1
                else:
                    energy[inter_Energy] = 1


        random_energy = list(energy.keys())
        energy_Count = list(energy.values())
        sorted_index = np.argsort(random_energy)
        total_sum = sum(energy_Count)
        random_energy, energy_Count = np.array(random_energy), np.array(energy_Count)
        energy_Unique, energy_Count = random_energy[sorted_index], energy_Count[sorted_index]
        energy_Count = energy_Count/total_sum

        Index_Th = np.where(energy_Unique == energyThreshold)[0][0]
        sum_PE = np.round(np.sum(energy_Count[:Index_Th]), decimals=3)

        fraction.append(sum_PE)

    ax.plot(E_Th, fraction, '-o', color=color3, markersize=ms, linewidth=0.5)
    print (E_Th, fraction, 'simulation')


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,1.01,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,1.1,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(-10,-1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(-10,-1,2), minor = False)

    ax.set_title('{}'.format(Title[0]), loc='left', fontweight="bold")
    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    ax.set_ylabel(r'Compatible fraction', fontsize=fontsizeX, labelpad=6.0)
    ax.legend(['neutral', 'evolved', 'marginal'], frameon=False, fontsize=fontticks)
    ax.set_xlim([-10.4,-1.7])
    ax.set_ylim([-0.020,1])
    







    color1, color2, color3, color4 = mcolors.TABLEAU_COLORS['tab:blue'], mcolors.TABLEAU_COLORS['tab:red'], \
                                        mcolors.TABLEAU_COLORS['tab:gray'], mcolors.TABLEAU_COLORS['tab:cyan']


    rnase_entropy = []
    for rnase_weight in weight_RNAse_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, weight)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight in weight_SLF_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, weight)]
        slf_entropy.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '\n \n')




    ax = plt.subplot(2, 3, 2)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    plt.plot(EnergyValue, rnase_entropy, '-o', color=color1, ms=ms, linewidth=0.5)
    plt.plot(EnergyValue, slf_entropy, '-o', color=color2, ms=ms, linewidth=0.5)


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.825,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.825,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(-10,-1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(-10,-1,2), minor = False)

    ax.set_title('{}'.format(Title[1]), loc='left', fontweight="bold")
    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\psi || \nu) ~[\mathrm{nat}], \nu = $prior', fontsize=fontsizeX)
    ax.legend([r'$\psi^{\mathrm{RNase}}$', r'$\psi^{\mathrm{SLF}}$'], frameon=False, fontsize=fontticks+1)
    ax.set_xlim([-10.4,-1.7])
    ax.set_ylim([-0.035,0.825])






    rnase_entropy = []
    for rnase_weight in weight_slfs_RNAse_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, weight)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight in weight_slfs_SLF_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, weight)]
        slf_entropy.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '\n \n')




    ax = plt.subplot(2, 3, 3)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    no_of_slfs_per_hap = [1, 2, 3, 4, 7, 9]

    plt.plot(no_of_slfs_per_hap, rnase_entropy, '-o', color=color1, ms=ms, linewidth=0.5)
    plt.plot(no_of_slfs_per_hap, slf_entropy, '-o', color=color2, ms=ms, linewidth=0.5)


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.85,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,1.0,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(1.0,9.5,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(1,9.5,1), minor = False)

    ax.set_title('{}'.format(Title[2]), loc='left', fontweight="bold")
    ax.set_xlabel(r'# SLFs per haplotype', fontsize=fontsizeX)
    #ax.set_ylabel(r'Compatible fraction', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\psi || \nu) ~ [\mathrm{nat}], \nu = $prior', fontsize=fontsizeX)
    ax.legend([r'$\psi^{\mathrm{RNase}}$', r'$\psi^{\mathrm{SLF}}$'], frameon=False, fontsize=fontticks+1)
    ax.set_xlim([0.75, 9.25])
    #ax.set_ylim([0.5,1])
    ax.set_ylim([-0.035,0.825])









    weight_RNAse_Data = np.genfromtxt('./kl_diver/avoid_self_fert/slf9/joint_aa_fre/marginal_rnases_aa.dat') # one pressure: avoiding SC
    weight_SLF_Data = np.genfromtxt('./kl_diver/avoid_self_fert/slf9/joint_aa_fre/marginal_slfs_aa.dat') # one pressure: avoiding SC

    weight_RNAse_Data_main_model = np.genfromtxt('./kl_diver/joint_aa_fre/marginal_rnases_aa.dat') # main model
    weight_SLF_Data_main_model = np.genfromtxt('./kl_diver/joint_aa_fre/marginal_slfs_aa.dat') # main model


    print (weight_RNAse_Data, '\n')
    print (weight_RNAse_Data_main_model, '\n')

    print (weight_SLF_Data, '\n')
    print (weight_SLF_Data_main_model, '\n')


    rnase_entropy = []
    for rnase_weight, rnase_weight_main_model in zip(weight_RNAse_Data, weight_RNAse_Data_main_model):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, rnase_weight_main_model)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight, slf_weight_main_model in zip(weight_SLF_Data, weight_SLF_Data_main_model):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, slf_weight_main_model)]
        slf_entropy.append(sum(entropy))

    rnase_entropy_re = []
    for rnase_weight, rnase_weight_main_model in zip(weight_RNAse_Data_main_model, weight_RNAse_Data):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, rnase_weight_main_model)]
        rnase_entropy_re.append(sum(entropy))

    slf_entropy_re = []
    for slf_weight, slf_weight_main_model in zip(weight_SLF_Data_main_model, weight_SLF_Data):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, slf_weight_main_model)]
        slf_entropy_re.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    rnase_entropy_re = np.round(rnase_entropy_re, decimals=3)
    slf_entropy_re = np.round(slf_entropy_re, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '\n \n')




    ax = plt.subplot(2, 3, 5)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    #plt.plot(np.arange(1,10,1), rnase_entropy, '--o', color=color1, ms=ms, linewidth=0.5)
    #plt.plot(np.arange(1,10,1), slf_entropy, '--o', color=color2, ms=ms, linewidth=0.5)

    plt.plot(np.arange(1,10,1), rnase_entropy_re, '-o', color=color1, ms=ms, linewidth=0.5)
    plt.plot(np.arange(1,10,1), slf_entropy_re, '-o', color=color2, ms=ms, linewidth=0.5)


    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.9,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.85,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(1,len(EnergyValue)+1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(1,10,1), EnergyValue, minor = False)

    ax.set_title('{}'.format(Title[4]), loc='left', fontweight="bold")
    ax.set_title('# SLFs = 9', loc='center', fontsize=fontsizeX-1)
    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}$(P || Q), Q = main model', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\psi || \hat{\psi})$ [nat]', fontsize=fontsizeX)
    #ax.legend([r'$P({\mathrm{RNase}})$', r'$P({\mathrm{SLF}})$'], frameon=False, fontsize=fontticks)
    ax.legend([r'RNase', r'SLF'], frameon=False, fontsize=fontticks, loc=2)
    ax.set_xlim([0.75,9.25])
    ax.set_ylim([-0.035,0.875])






    weight_rnase_avoid_sc_slf9 = genfromtxt('./kl_diver/from_mathematica/rnase_marginal_slf9.dat')
    weight_rnase_avoid_sc_slf9 = weight_rnase_avoid_sc_slf9[9:,:] # before that data are old data
    weight_slf_avoid_sc_slf9_nor = genfromtxt('./kl_diver/from_mathematica/conditional_prob_slf9.dat')
    weight_slf_avoid_sc_slf9_nor = weight_slf_avoid_sc_slf9_nor[36:,:] # before that data are old data
    weight_slf_avoid_sc_slf9_nor = weight_slf_avoid_sc_slf9_nor.reshape((9,4,4)) 

    weight_slf_avoid_sc_slf9  = []
    for w_rnase, w_slf in zip(weight_rnase_avoid_sc_slf9, weight_slf_avoid_sc_slf9_nor):
        slf_marginal = []
        w_slf = w_slf.T
        for ind in range(4):
            slf_marginal.append(sum(w_slf[ind]*w_rnase))
        slf_marginal = np.array(slf_marginal/sum(slf_marginal))
        weight_slf_avoid_sc_slf9.append(slf_marginal)
    weight_slf_avoid_sc_slf9 = np.array(weight_slf_avoid_sc_slf9)


    def kl_diver_cal(input_1, input_2):
        weight_RNAse_Data, weight = input_1, input_2
        rnase_entropy = []
        for rnase_weight, ref_weight in zip(weight_RNAse_Data, weight):
            entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, ref_weight)]
            rnase_entropy.append(sum(entropy))
        return np.round(rnase_entropy, decimals=3)




    rnase_entropy = []
    for rnase_weight in weight_RNAse_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, weight)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight in weight_SLF_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, weight)]
        slf_entropy.append(sum(entropy))


    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '----------------', '\n \n')


    ax = plt.subplot(2, 3, 4)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    plt.plot(np.arange(1,10,1), rnase_entropy, '-o', color=color1, ms=ms, linewidth=0.5)
    plt.plot(np.arange(1,10,1), slf_entropy, '-o', color=color2, ms=ms, linewidth=0.5)
    #plt.plot(np.arange(1,10,1), kl_diver_cal(weight_rnase_avoid_sc_slf9, [weight for i in range(9)]), '--^', color=color3, ms=ms, linewidth=0.5)
    #plt.plot(np.arange(1,10,1), kl_diver_cal(weight_slf_avoid_sc_slf9, [weight for i in range(9)]), '--^', color=color4, ms=ms+0.0, linewidth=0.5)

    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.9,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.85,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(1,len(EnergyValue)+1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(1,10,1), EnergyValue, minor = False)

    ax.set_title('{}'.format(Title[3]), loc='left', fontweight="bold")
    ax.set_title('# SLFs = 9', loc='center', fontsize=fontsizeX-1)
    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}$(P || Q), Q = main model', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\hat{\psi} || \nu)$ [nat]', fontsize=fontsizeX)
    #ax.legend([r'$P({\mathrm{RNase}})$', r'$P({\mathrm{SLF}})$'], frameon=False, fontsize=fontticks)
    #ax.legend([r'$\hat{\psi}^{\mathrm{RNase}}_{_{\mathrm{simulation}}}$', r'$\hat{\psi}^{\mathrm{SLF}}_{_{\mathrm{simulation}}}$', \
    #           r'$\hat{\psi}^{\mathrm{RNase}}_{_{\mathrm{analytical}}}$', r'$\hat{\psi}^{\mathrm{SLF}}_{_{\mathrm{analytical}}}$'], frameon=False, fontsize=fontticks+1, loc=2, ncols=2)
    ax.legend([r'$\hat{\psi}^{\mathrm{RNase}}$', r'$\hat{\psi}^{\mathrm{SLF}}$'], frameon=False, fontsize=fontticks+1, loc=2, ncols=2)

    ax.set_xlim([0.75,9.25])
    ax.set_ylim([-0.035,0.875])












    weight_rnase_avoid_sc_slf1 = genfromtxt('./kl_diver/from_mathematica/rnase_marginal_slf1.dat')
    weight_rnase_avoid_sc_slf1 = weight_rnase_avoid_sc_slf1[9:,:] # before that data are old data
    weight_slf_avoid_sc_slf1_nor = genfromtxt('./kl_diver/from_mathematica/conditional_prob_slf1.dat')
    weight_slf_avoid_sc_slf1_nor = weight_slf_avoid_sc_slf1_nor[36:,:] # before that data are old data
    weight_slf_avoid_sc_slf1_nor = weight_slf_avoid_sc_slf1_nor.reshape((9,4,4))

    weight_slf_avoid_sc_slf1  = []
    for w_rnase, w_slf in zip(weight_rnase_avoid_sc_slf1, weight_slf_avoid_sc_slf1_nor):
        slf_marginal = []
        w_slf = w_slf.T
        for ind in range(4):
            slf_marginal.append(sum(w_slf[ind]*w_rnase))
        slf_marginal = np.array(slf_marginal/sum(slf_marginal))
        weight_slf_avoid_sc_slf1.append(slf_marginal)
    weight_slf_avoid_sc_slf1 = np.array(weight_slf_avoid_sc_slf1)

    print (weight_rnase_avoid_sc_slf1)
    print (weight_slf_avoid_sc_slf1, '-------')







    weight_RNAse_Data = np.genfromtxt('./kl_diver/avoid_self_fert/slf1/joint_aa_fre/marginal_rnases_aa.dat') # one pressure: avoiding SC
    weight_SLF_Data = np.genfromtxt('./kl_diver/avoid_self_fert/slf1/joint_aa_fre/marginal_slfs_aa.dat') # one pressure: avoiding SC

    weight_RNAse_Data_main_model = np.genfromtxt('./kl_diver/joint_aa_fre/marginal_rnases_aa.dat') # main model
    weight_SLF_Data_main_model = np.genfromtxt('./kl_diver/joint_aa_fre/marginal_slfs_aa.dat') # main model


    print (weight_RNAse_Data, '\n')
    print (weight_RNAse_Data_main_model, '\n')

    print (weight_SLF_Data, '\n')
    print (weight_SLF_Data_main_model, '\n')


    rnase_entropy = []
    for rnase_weight, rnase_weight_main_model in zip(weight_RNAse_Data, weight_RNAse_Data_main_model):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, rnase_weight_main_model)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight, slf_weight_main_model in zip(weight_SLF_Data, weight_SLF_Data_main_model):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, slf_weight_main_model)]
        slf_entropy.append(sum(entropy))

    rnase_entropy_re = []
    for rnase_weight, rnase_weight_main_model in zip(weight_RNAse_Data_main_model, weight_RNAse_Data):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, rnase_weight_main_model)]
        rnase_entropy_re.append(sum(entropy))

    slf_entropy_re = []
    for slf_weight, slf_weight_main_model in zip(weight_SLF_Data_main_model, weight_SLF_Data):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, slf_weight_main_model)]
        slf_entropy_re.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)

    rnase_entropy_re = np.round(rnase_entropy_re, decimals=3)
    slf_entropy_re = np.round(slf_entropy_re, decimals=3)

    print (rnase_entropy)
    print (slf_entropy, '\n \n')




    rnase_entropy = []
    for rnase_weight in weight_RNAse_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, weight)]
        rnase_entropy.append(sum(entropy))

    slf_entropy = []
    for slf_weight in weight_SLF_Data:
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(slf_weight, weight)]
        slf_entropy.append(sum(entropy))


    r_s_entropy = []
    for rnase_weight, slf_weight in zip(weight_RNAse_Data, weight_SLF_Data):
        entropy = [px*np.log2(px/qx) if qx > 0 else 0 for px, qx in zip(rnase_weight, slf_weight)]
        r_s_entropy.append(sum(entropy))

    rnase_entropy = np.round(rnase_entropy, decimals=3)
    slf_entropy = np.round(slf_entropy, decimals=3)
    r_s_entropy = np.round(r_s_entropy, decimals=3)


    print (rnase_entropy)
    print (slf_entropy, '\n \n')


    ax = plt.subplot(2, 3, 6)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    plt.plot(np.arange(1,10,1), rnase_entropy, '-o', color=color1, ms=ms, linewidth=0.5)
    plt.plot(np.arange(1,10,1), slf_entropy, '-o', color=color2, ms=ms, linewidth=0.5)
    #plt.plot(np.arange(1,10,1), kl_diver_cal(weight_rnase_avoid_sc_slf1, [weight for i in range(9)]), '--^', color=color3, ms=ms, linewidth=0.5)
    #plt.plot(np.arange(1,10,1), kl_diver_cal(weight_slf_avoid_sc_slf1, [weight for i in range(9)]), '--^', color=color4, ms=ms, linewidth=0.25)

    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.9,0.05), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(0,0.85,0.2), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(1,len(EnergyValue)+1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
    ax.set_xticks(np.arange(1,10,1), EnergyValue, minor = False)

    ax.set_title('{}'.format(Title[5]), loc='left', fontweight="bold")
    ax.set_title('# SLFs = 1', loc='center', fontsize=fontsizeX-1)
    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}$(P || Q), Q = main model', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\hat{\psi} || \nu)$ [nat]', fontsize=fontsizeX)
    #ax.legend([r'$P({\mathrm{RNase}})$', r'$P({\mathrm{SLF}})$'], frameon=False, fontsize=fontticks)
    #ax.legend([r'RNase', r'SLF'], frameon=False, fontsize=fontticks, loc=9)
    #ax.legend([r'$\hat{\psi}^{\mathrm{RNase}}_{_{\mathrm{simulation}}}$', r'$\hat{\psi}^{\mathrm{SLF}}_{_{\mathrm{simulation}}}$', \
    #           r'$\hat{\psi}^{\mathrm{RNase}}_{_{\mathrm{analytical}}}$', r'$\hat{\psi}^{\mathrm{SLF}}_{_{\mathrm{analytical}}}$'], frameon=False, fontsize=fontticks+1, loc=1, ncols=2)
    ax.legend([r'$\hat{\psi}^{\mathrm{RNase}}$', r'$\hat{\psi}^{\mathrm{SLF}}$'], frameon=False, fontsize=fontticks+1, loc=1, ncols=2)
    ax.set_xlim([0.75,9.25])
    ax.set_ylim([-0.035,0.875])




    ax = inset_axes(ax, 1.25, 0.75 , loc=1, bbox_to_anchor=(1.0, 0.375), bbox_transform=ax.figure.transFigure)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    ax.plot(np.arange(1,10,1), r_s_entropy, '-o', color=color3, ms=ms, linewidth=0.5)

    ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
    ax.set_yticks(np.arange(0,0.9,0.1), minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
    ax.set_yticks(np.arange(0,0.85,0.5), minor = False)

    ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
    ax.set_xticks(np.arange(1,len(EnergyValue)+1,1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
    ax.set_xticks(np.arange(1,10,2), [-10, -8, -6, -4, -2], minor = False)

    ax.set_xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeX-2)
    #ax.set_ylabel(r'$D_{\mathrm{KL}}$(P || Q), Q = main model', fontsize=fontsizeX)
    ax.set_ylabel(r'$D_{\mathrm{KL}}(\hat{\psi}^{\mathrm{RNase}} || \hat{\psi}^{\mathrm{SLF}})$ [nat]', fontsize=fontsizeX)
    #ax.legend([r'$P({\mathrm{RNase}})$', r'$P({\mathrm{SLF}})$'], frameon=False, fontsize=fontticks)
    #ax.legend([r'RNase', r'SLF'], frameon=False, fontsize=fontticks, loc=2)
    ax.set_xlim([0.75,9.25])
    ax.set_ylim([-0.050,0.575])




    #plt.tight_layout()
    plt.savefig('Figure_4.pdf', transparent=True)
    #plt.show()
    plt.close()

    return 'done'

print (plot_prob_AA_Paper(0))
#print (plot_prob_AA_Paper(['./fig_E-10', './fig_E-9', './fig_E-8', './fig_E-7', './fig_E-6', './fig_E-5', './fig_E-4', './fig_E-3', './fig_E-2', './papers', 'SLF']))
#print (plot_prob_AA_Paper(['./fig_E-10', './fig_E-9', './fig_E-8', './fig_E-7', './fig_E-6', './fig_E-5', './fig_E-4', './fig_E-3', './fig_E-2', './papers', 'FunSLF']))
#print (plot_prob_AA_Paper(['./fig_E-10', './fig_E-9', './fig_E-8', './fig_E-7', './fig_E-6', './fig_E-5', './fig_E-4', './fig_E-3', './fig_E-2', './papers', 'NonFunSLF']))

#print (plot_prob_AA_Paper(['./fig_newE-10', './fig_newE-6', './fig_newE-2', './newfigures', 'SLF']))
#print (plot_prob_AA_Paper(['./fig_newE-10', './fig_newE-6', './fig_newE-2', './newfigures', 'RNAse']))
#print (plot_prob_AA_Paper(['./fig_newE-10', './fig_newE-6', './fig_newE-2', './newfigures', 'FunSLF']))
#print (plot_prob_AA_Paper(['./fig_newE-10', './fig_newE-6', './fig_newE-2', './newfigures', 'NonFunSLF']))


print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
