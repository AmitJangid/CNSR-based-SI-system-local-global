#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
from numba import jit # type: ignore
import pickle
from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import matplotlib as mpl # type: ignore
import matplotlib.colors as mcolors
Color = ['tab:blue', 'tab:red', 'tab:green', 'tab:gray', 'tab:purple', 'tab:brown', 'tab:pink','tab:orange', 'tab:cyan', 'tab:olive']
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

weight = [0.5, 0.265, 0.113, 0.122]

#
#
#
#############
def plot_prob_AA_Paper(input_Var): # Box plot






    Samples = 25

    gen_Index = [0, 1]
    fontsizeX, fontsizeY, fonttitle, fontticks = 8, 8, 8, 6
    AminoAcid = ['H', 'P', '+', '-']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];
    my_colors = ['k', 'k', 'k', 'k', 'k', 'k', 'k','k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k']
    my_colors_Box = ['w', 'w', 'w', 'w', 'w', 'w', 'w','w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w', 'w','w', 'w']



    def flatten_extend(matrix):
        flat_list = []
        for row in matrix:  flat_list.extend(row)
        return flat_list


    ########
    ###########
    #############

    def flatten_extend(matrix):
        matrix = np.array(matrix)
        flat_list = []
        if len(np.shape(matrix)) == 1:
            flat_list = matrix
        else:
            for row in matrix:  
                flat_list.extend(row)
        return flat_list



    plt.figure(figsize=(8,6.25))
    plt.subplots_adjust(top=0.964, bottom=0.076, left=0.057, right=0.992, hspace=0.320, wspace=0.160)
    window_Size = 500

    EnergyValue = [-10, -9, -8, -7, -6, -5, -4, -3, -2][0:]
    input_VarPath = input_Var[:-2][0:]



    EnergyValue = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
    eth_index = np.array(list(range(len(EnergyValue))))
    tempPath = './aa_frequency/avoid_self_fert/slf9'
    input_VarPath = [tempPath+'/fig_E{}_a90_d90'.format(eth_) for eth_ in EnergyValue]
    input_VarPath_1 = './aa_frequency/from_mathematica'
    input_VarPath_2 = ['./aa_frequency/main_model'+'/fig_E{}_a90_d90'.format(eth_) for eth_ in EnergyValue]


    Samples = 25

    # temp SLF and RNAse
    temp_SLF_pH = []
    temp_RNAse_pH = []

    gen_Index = [0, 1, 2]
    all_samples = [i for i in range(Samples)]
    final_print_aa = []
    print_Final = np.array([np.array([0 for j in range(4)]) for i in range(9)], dtype=float)
    for AA_value in [0,1,2,3][:]:
        data_mean = []
        data_std = []
        data_mean_emp = []
        data_std_emp = []
        for gen_Ind in gen_Index:
            if gen_Ind == 0:
                typeOfGene = 'RNAse'; gen_Ind_data = -450
            if gen_Ind == 1:
                typeOfGene = 'RNAse'; gen_Ind_data = -450
            if gen_Ind == 2:
                typeOfGene = 'RNAse'; gen_Ind_data = -450

            for i, pathToPick, pathToPick_1, pathToPick_2 in zip(range(len(input_VarPath)), input_VarPath, input_VarPath_1, input_VarPath_2):
                all_copy_No_AA = []
                for SampleNo in all_samples:
                    if gen_Ind == 0:
                        copy_No_AA = np.genfromtxt(pathToPick+'/data_{}/copy_no_aa_{}.dat'.format(SampleNo, typeOfGene, SampleNo))
                        copy_No_AA = copy_No_AA[gen_Ind_data:,AA_value]/copy_No_AA[gen_Ind_data:,4]
                        all_copy_No_AA.append(copy_No_AA)

                    if gen_Ind == 1:
                        #print (input_VarPath_1)
                        copy_No_AA = np.genfromtxt(input_VarPath_1 + '/rnase_marginal_slf9.dat')
                        copy_No_AA = copy_No_AA[9:,:]
                        copy_No_AA = copy_No_AA[i, AA_value]
                        all_copy_No_AA.append([copy_No_AA])

                    if gen_Ind == 2:
                        copy_No_AA = np.genfromtxt(pathToPick_2+'/data_{}/copy_no_aa_{}.dat'.format(SampleNo, typeOfGene, SampleNo))
                        copy_No_AA = copy_No_AA[gen_Ind_data:,AA_value]/copy_No_AA[gen_Ind_data:,4]
                        all_copy_No_AA.append(copy_No_AA)

                
                #print (np.shape(np.array(all_copy_No_AA)))
                data_mean.append(np.mean(flatten_extend(all_copy_No_AA)))
                data_std.append(np.std(flatten_extend(all_copy_No_AA)))

        data_exp = np.array([[0.228, 0.338, 0.145, 0.290],\
                             [0.213, 0.415, 0.170, 0.202],\
                             [0.242, 0.417, 0.150, 0.192]])

        data_mean_emp.append(np.mean(data_exp[:,AA_value]))
        data_std_emp.append(np.std(data_exp[:,AA_value]))

        data_mean_emp = np.array(data_mean_emp)
        data_std_emp = np.array(data_std_emp)

        #print (np.mean(all_Copy[0]), np.mean(all_Copy[4]), np.mean(all_Copy[8]))
        #print (np.mean(all_Copy[12]), np.mean(all_Copy[16]), np.mean(all_Copy[20]))
        #ax = plt.subplot2grid((36,55), (int(AA_value/2)*(13), (AA_value%2)*29), colspan=26, rowspan=10)

        ax = plt.subplot(2,2,AA_value+1)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)


        multiple_value = 0.10
        data_mean, data_std = np.array(data_mean), np.array(data_std)
        final_print_aa.append(data_mean)
        #print (list(np.round(data_std[:9]**2/data_mean[:9], decimals=3)), '---- 9SLF, reduced model')

        change_pos_1, change_pos_2, change_pos_3 = -0.15, 0.0, 0.15

        ax.plot(eth_index+1.0+change_pos_3, data_mean[18:], '*', ms=5, lw=0.5, color=mcolors.TABLEAU_COLORS['tab:blue'], label=r'$\psi^{\mathrm{RNase}}_{\mathrm{full~model}}$')
        ax.plot(eth_index+1.0+change_pos_1, data_mean[:9], 'o', ms=5, lw=0.5, color=mcolors.TABLEAU_COLORS['tab:cyan'], label=r'$\hat{\psi}^{\mathrm{RNase}}_{\mathrm{reduced~model}}$')
        ax.plot(eth_index+1.0+change_pos_2, data_mean[9:18], '^', ms=5, lw=0.5, color=mcolors.TABLEAU_COLORS['tab:red'], label=r'$\hat{\psi}^{\mathrm{RNase}}_{\mathrm{analytical}}$')

        fill_height = [0.5, 0.5, 0.5, 0.5]
        ax.fill_between([10.65,11.35], 0, fill_height[AA_value], color='k', alpha=0.075, edgecolor=None)
        ax.plot([11], data_mean_emp, 'o', ms=5, lw=0.5, color='k', label=r'empirical')

        for eth, index in zip(eth_index+1.0, range(len(EnergyValue))):
            ax.vlines(eth+change_pos_1, (data_mean-data_std)[index], (data_mean+data_std)[index], lw=1.0, color=mcolors.TABLEAU_COLORS['tab:cyan'])
            ax.hlines((data_mean-data_std)[index], eth-multiple_value+change_pos_1, eth+multiple_value+change_pos_1, lw=1.0, color=mcolors.TABLEAU_COLORS['tab:cyan'])
            ax.hlines((data_mean+data_std)[index], eth-multiple_value+change_pos_1, eth+multiple_value+change_pos_1, lw=1.0, color=mcolors.TABLEAU_COLORS['tab:cyan'])

        for eth, index in zip(eth_index+1.0, range(len(EnergyValue), len(EnergyValue)*2)):
            ax.vlines(eth+change_pos_2, (data_mean-data_std)[index], (data_mean+data_std)[index], lw=1.0, color=mcolors.TABLEAU_COLORS['tab:red'])
            ax.hlines((data_mean-data_std)[index], eth-multiple_value+change_pos_2, eth+multiple_value+change_pos_2, lw=1.0, color=mcolors.TABLEAU_COLORS['tab:red'])
            ax.hlines((data_mean+data_std)[index], eth-multiple_value+change_pos_2, eth+multiple_value+change_pos_2, lw=1.0, color=mcolors.TABLEAU_COLORS['tab:red'])

        for eth, index in zip(eth_index+1.0, range(len(EnergyValue)*2, len(EnergyValue)*3)):
            ax.vlines(eth+change_pos_3, (data_mean-data_std)[index], (data_mean+data_std)[index], lw=1.0, color=mcolors.TABLEAU_COLORS['tab:blue'])
            ax.hlines((data_mean-data_std)[index], eth-multiple_value+change_pos_3, eth+multiple_value+change_pos_3, lw=1.0, color=mcolors.TABLEAU_COLORS['tab:blue'])
            ax.hlines((data_mean+data_std)[index], eth-multiple_value+change_pos_3, eth+multiple_value+change_pos_3, lw=1.0, color=mcolors.TABLEAU_COLORS['tab:blue'])

        ax.vlines([11], (data_mean_emp-data_std_emp), (data_mean_emp+data_std_emp), lw=1.0, color='k')
        ax.hlines((data_mean_emp-data_std_emp), 11-multiple_value+change_pos_2, 11+multiple_value+change_pos_2, lw=1.0, color='k')
        ax.hlines((data_mean_emp+data_std_emp), 11-multiple_value+change_pos_2, 11+multiple_value+change_pos_2, lw=1.0, color='k')





        if AA_value in [2,3]:
            plt.xlabel(r'$E_{\mathrm{th}}$', fontsize=fontsizeY+3)
        #else:
        #    plt.xticks([])
        if typeOfGene == 'FunSLF':
            if AA_value==0:
                plt.ylabel(r'$\langle f{(\mathrm{H})}\rangle$', fontsize=fontsizeY+3)
            elif AA_value==1:
                plt.ylabel(r'$\langle f{(\mathrm{P})}\rangle$', fontsize=fontsizeY+3)
            elif AA_value==2:
                plt.ylabel(r'$\langle f{(\mathrm{+})}\rangle$', fontsize=fontsizeY+3)
            else:
                plt.ylabel(r'$\langle f{(\mathrm{-})}\rangle$', fontsize=fontsizeY+3)
        else:
            if AA_value==0:
                plt.ylabel(r'$\langle f{(\mathrm{H})}\rangle$', fontsize=fontsizeY+3)
            elif AA_value==1:
                plt.ylabel(r'$\langle f{(\mathrm{P})}\rangle$', fontsize=fontsizeY+3)
            elif AA_value==2:
                plt.ylabel(r'$\langle f{(\mathrm{+})}\rangle$', fontsize=fontsizeY+3)
            else:
                plt.ylabel(r'$\langle f{(\mathrm{-})}\rangle$', fontsize=fontsizeY+3)

            #plt.ylabel(r'$p($'+'{}'.format(['H','P','+','-'][AA_value])+r'$)$', fontsize=fontsizeY+3)
            

        plt.yticks(fontsize=fontticks)
        plt.title('{}'.format(Title[AA_value]), loc='left', fontweight="bold")
        #plt.title(r'----- $p$'+'({})'.format(AminoAcid[AA_value])+r'$_{\mathrm{prior}}$', loc='center', fontsize=fontticks+3)

        if AA_value == 0:
            plt.title(r'----- $\nu_{\mathrm{H}}$', loc='center', fontsize=fontticks+5)
        elif AA_value == 1:
            plt.title(r'----- $\nu_{\mathrm{P}}$', loc='center', fontsize=fontticks+5)
        elif AA_value == 2:
            plt.title(r'----- $\nu_{\mathrm{+}}$', loc='center', fontsize=fontticks+5)
        else:
            plt.title(r'----- $\nu_{\mathrm{-}}$', loc='center', fontsize=fontticks+5)

        #plt.title('at equilibrium', loc='right', fontsize=fonttitle-2)
        if len(EnergyValue) in [7,8,9,10]:
            plt.xlim([0.45,len(EnergyValue)+0.5+2])
        if len(EnergyValue) == 6:
            plt.xlim([0.45,len(EnergyValue)*2+1.5])

        if len(EnergyValue) in [7,8,9,10]:
            plt.xticks([1,2,3,4,5,6,7,8,9,11], [-10,-9,-8,-7,-6,-5,-4,-3,-2,'emprirical\ndata'], fontsize=fontticks, rotation=0)
        if len(EnergyValue) == 6:
            ax.tick_params(axis = 'x', which = 'minor', labelsize = 0)
            ax.set_yticks([i for i in range(1,len(EnergyValue)*2+2) if i not in [len(EnergyValue)+1, len(EnergyValue)+1]], EnergyValue*2, minor = True)
            plt.xticks([i for i in range(1,len(EnergyValue)*2+2) if i not in [len(EnergyValue)+1, len(EnergyValue)+1]], EnergyValue*2, fontsize=fontticks, rotation=0)

        plt.hlines(weight[AA_value], 0.5, len(EnergyValue)*2+2.5, linestyle='dashed', color='k', linewidth=0.5)

        rnase_slf_legend = [0.67, 0.685, 0.47, 0.540]

        xx_r, xx_s, xx_ss, add_x = 1.25, 4.00, 6.50, 0.75 #1.75, 12.25 if eth from -7
        # plt.hlines(rnase_slf_legend[AA_value], xx_r, xx_r+add_x, color='c', linestyle='-', lw=5.0, alpha=0.5)
        # plt.hlines(rnase_slf_legend[AA_value], xx_s, xx_s+add_x, color='#D43F3A', linestyle='-', lw=5.0, alpha=0.5)
        # plt.hlines(rnase_slf_legend[AA_value], xx_ss, xx_ss+add_x, color='b', linestyle='-', lw=5.0, alpha=0.5)
        # plt.text(xx_r+add_x+0.25, rnase_slf_legend[AA_value]*(1 - 0.0120), r'$\hat{\psi}^{\mathrm{RNase}}_{\mathrm{simulation}}$', alpha=0.75, fontsize=fontsizeX)
        # plt.text(xx_s+add_x+0.25, rnase_slf_legend[AA_value]*(1 - 0.0120), r'$\hat{\psi}^{\mathrm{RNase}}_{\mathrm{analytical}}$', alpha=0.75, fontsize=fontsizeX)
        # plt.text(xx_ss+add_x+0.25, rnase_slf_legend[AA_value]*(1 - 0.0120), r'$\psi^{\mathrm{RNase}}_{\mathrm{full~model}}$', alpha=0.75, fontsize=fontsizeX)
        if AA_value==0:
            ax.legend(ncols=2, fontsize=fontticks+3, frameon=False, loc=1)

        if AA_value==0:
            ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
            ax.set_yticks(np.arange(0,0.7,0.02), minor = True)
            plt.yticks([0.0,0.2,0.4,0.6], fontsize=fontticks)
            plt.ylim([0.0, 0.7])
        if AA_value==1:
            ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
            ax.set_yticks(np.arange(0.0,0.7,0.02), minor = True)
            plt.yticks([0.0,0.1,0.2,0.3,0.4,0.5], fontsize=fontticks)
            plt.ylim([0.1, 0.58])
        if AA_value in [2]:
            ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
            ax.set_yticks(np.arange(0,0.51,0.02), minor = True)
            plt.yticks([0.0,0.1,0.2,0.3,0.4,0.5], fontsize=fontticks)
            plt.ylim([-0.0, 0.5])
        if AA_value in [3]:
            ax.tick_params(axis = 'y', which = 'minor', labelsize = 0)
            ax.set_yticks(np.arange(0,0.57,0.02), minor = True)
            plt.yticks([0.0,0.1,0.2,0.3,0.4,0.5], fontsize=fontticks)
            plt.ylim([-0.0, 0.5])

        for ticklabel, tickcolor in zip(plt.gca().get_xticklabels(), my_colors):
            ticklabel.set_color(tickcolor)

        #plt.grid(axis='both', data=[np.arange(1,20,1), np.arange(0,0.7,0.02)], linewidth=0.05, alpha=0.45, linestyle='--')
        #plt.grid(axis='y', which='minor', linewidth=0.05, alpha=0.45, linestyle='--')

        temp_pH = []
        #sprint (all_Copy)
        #for temp_data in all_Copy:
        #    if len(temp_data) > 2:
        #        temp_pH.append(np.round(np.mean(temp_data), decimals=4))

        #temp_RNAse_pH.append(np.array(temp_pH[:int(len(temp_pH)/2)]))
        #temp_SLF_pH.append(np.array(temp_pH[int(len(temp_pH)/2):]))

    #print (np.array(temp_RNAse_pH).T, '\n')
    #print (np.array(temp_SLF_pH).T)
    #print (np.array(final_print_aa).T)
    print ('\n')

    #plt.tight_layout()
    
    plt.savefig('Figure_5.pdf'.format(typeOfGene), transparent=True)
    #plt.show()
    plt.close()
    




    #plt.tight_layout()
    #plt.savefig('./figures_si/si_fig_different_slfs.pdf'.format(typeOfGene), transparent=True)
    #plt.show()
    #plt.close()

    return 'done'

main_path = '../variable_ene_al_dl'
print (plot_prob_AA_Paper([main_path + '/fig_E-10_a90_d90', main_path + '/fig_E-9_a90_d90', main_path + '/fig_E-8_a90_d90', \
                            main_path + '/fig_E-7_a90_d90', main_path + '/fig_E-6_a90_d90', main_path + '/fig_E-5_a90_d90', \
                            main_path + '/fig_E-4_a90_d90', main_path + '/fig_E-3_a90_d90', main_path + '/fig_E-2_a90_d90', \
                            './figures', 'RNAse']))



print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
