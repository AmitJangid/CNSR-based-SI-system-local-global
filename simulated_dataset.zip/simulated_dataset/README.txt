Reconciling conflicting selection pressures in the plant collaborative non-self recognition self-incompatibility system
Amit Jangid (1), Keren Erez (1), Ohad Noy Feldheim (2) and Tamar Friedlander (1)

    (1) The Robert H. Smith Institute of Plant Sciences and Genetics in Agriculture
        Faculty of Agriculture, The Hebrew University of Jerusalem,
        P.O. Box 12 Rehovot 7610001, Israel
    (2) The Einstein Institute of Mathematics, Faculty of Natural Sciences,
        The Hebrew University of Jerusalem, Jerusalem 9190401, Israel.
       
    Correspondence: tamar.friedlander@mail.huji.ac.il.

###############################################################################################################

Details of the Python scripts to generate the figures of the main manuscript.

1. class_structure_fig2.py
   This python script generates Figure 2.

2. kl_divergence_fig4.py
   This python script generates Figure 4. 

3. fre_aa_fig5.py
   This python script generates Figure 5.
   
4. local_global_fig6.py
   This python script generates Figure 6.

###############################################################################################################  




